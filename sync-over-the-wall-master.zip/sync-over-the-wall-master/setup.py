from distutils.core import setup
import py2exe

setup(console=['tracker_proxy.py', 'config_server.py'])
